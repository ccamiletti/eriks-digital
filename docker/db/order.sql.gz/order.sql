-- Adminer 4.8.0 MySQL 5.7.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `eriks_db`;
CREATE DATABASE `eriks_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `eriks_db`;

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(50) DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `order` (`id`, `status`, `total_price`, `date`) VALUES
(1,	'ACCEPTED',	3333.5,	'2021-03-08 18:56:36'),
(2,	'OK',	9873.5,	'2021-11-08 18:56:36'),
(3,	'APPROVED',	3445.5,	'2021-10-08 19:56:36'),
(4,	'ACCEPTED',	2222.5,	'2018-02-08 18:56:36');

-- 2021-05-13 21:51:57
